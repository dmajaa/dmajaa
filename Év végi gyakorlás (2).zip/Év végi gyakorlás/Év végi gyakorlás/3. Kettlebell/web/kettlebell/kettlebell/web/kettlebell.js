﻿window.onload=function(){
    
    fetch('/api/arak')
        .then(function(response) {
            if (!response.ok) {
                throw new Error('Hiba történt a szerver válaszában.');
            }
            return response.json();
        })
        .then(function(data) {
            var kettlebellPrice = document.querySelector('.kiloar');
            var edzotervPrice = document.querySelector('.edzoterv');
            var tankonyvPrice = document.querySelector('.tankonyv');

            kettlebellPrice.innerText = data.kiloar;
            edzotervPrice.innerText = data.edzoterv;
            tankonyvPrice.innerText = data.tankonyv;

            var kedvezmenyElem = document.getElementById('kedvezmenyListaElem');
            var kedvezmenyText = data.kedvezmeny + '%-os kedvezmény a terembelépő árából';
            kedvezmenyElem.innerHTML = '<span class="fa-li"><i class="fas fa-check"></i></span>' + kedvezmenyText;
        })
        .catch(function(error) {
            console.error('Hiba történt a kérés során:', error);
        });
}

function gyakorlatGeneralas(){
    var ismetlesSzam = Math.floor(Math.random()*30)+1;
    var gyakorlatok = ["Swing", "Magasra húzás", "Serleg guggolás", "Szélmalom", "Török felállás"];

    var randomGyakorlat= Math.floor(Math.random() * gyakorlatok.length);
    var gyakorlatNeve=gyakorlatok[randomGyakorlat];

    var generaltGyakorlatElem = document.getElementById('generaltGyakorlat');
    generaltGyakorlatElem.innerText = ismetlesSzam + " darab " + gyakorlatNeve;
}

