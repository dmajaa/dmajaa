A feladatok megoldására elkészített SQL parancsokat illessze be a feladat sorszáma után!
***
14. feladat
CREATE DATABASE kettlebell
CHARACTER SET utf8mb4
COLLATE utf8mb4_hungarian_ci;

***
16. feladat
SELECT COUNT(*) As '20_kilos_felszerelesek_szama' FROM felszereles WHERE suly = '20';

***
17. feladat
SELECT honap, ar
FROM haviberlet h
JOIN vendeg v ON h.vendegId = v.id
WHERE v.nev = 'Tóth Levente';


***
18. feladat
UPDATE kategoria SET nev = 'Fém kettlebell' WHERE id = 1;

***
19. feladat
SELECT f.nev, f.suly, SUM(k.idotartam) AS 'Szumma_nap'
FROM kolcsonzes k
JOIN felszereles f ON k.felszerelesId = f.id
GROUP BY k.felszerelesId
ORDER BY SUM(k.idotartam) DESC
LIMIT 5; 

***
20. feladat
SELECT v.nev, COUNT(k.visszahozta) AS 'visszahozando_db'
FROM kolcsonzes k
JOIN vendeg v ON k.vendegId = v.id
WHERE k.visszahozta = 0
GROUP BY k.vendegId
ORDER BY COUNT(k.visszahozta) DESC
LIMIT 1;


