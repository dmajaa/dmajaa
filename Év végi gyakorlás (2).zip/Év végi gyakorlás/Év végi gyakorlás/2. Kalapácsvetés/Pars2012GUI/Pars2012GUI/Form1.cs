﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace Pars2012GUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Fajlbeolvasas();
            AdatokBetolteseCB();
            
        }

        List<Selejtezo> selejtezes = new List<Selejtezo>();

        private void Fajlbeolvasas()
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                StreamReader f = new StreamReader(openFileDialog1.FileName);
                f.ReadLine();
                while (!f.EndOfStream)
                {
                    selejtezes.Add(new Selejtezo(f.ReadLine()));

                }
            }
        }

        private void AdatokBetolteseCB()
        {
            
            for (int i = 0; i < selejtezes.Count; i++)
            {
                comboBox1.Items.Add(selejtezes[i].nev);

                if (selejtezes[i].nev == "Pars Krisztián")
                {
                    comboBox1.SelectedItem = selejtezes[i].nev;
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string valasztottNev = comboBox1.SelectedItem.ToString();
            Selejtezo valasztottSportolo = null;
            foreach (var sportolo in selejtezes)
            {
                if (sportolo.nev == valasztottNev)
                {
                    valasztottSportolo = sportolo;
                    break;
                }
            }

            if (valasztottSportolo != null)
            {

                label2.Text = "Csoport: " + valasztottSportolo.csoport;
                label3.Text = "Nemzet: " + valasztottSportolo.nemzet;
                label4.Text = "Kód: " + valasztottSportolo.kod;
                label5.Text = "Sorozat: " + valasztottSportolo.sorozat;
                label6.Text = "Eredmény: " + valasztottSportolo.eredmeny;
            }

            pictureBox1.ImageLocation = "../../Images/" + valasztottSportolo.kod + ".png";


        }

        class Selejtezo
        {

            public string nev, csoport, nemzeteskod, nemzet, kod, d1, d2, d3, sorozat, eredmeny;

            public Selejtezo(string sor)
            {
                string[] st = sor.Split(';');
                nev = st[0];
                csoport = st[1];
                nemzeteskod = st[2];
                d1 = st[3];
                d2 = st[4];
                d3 = st[5];
                sorozat = d1 + ";" + d2 + ";" + d3;
                eredmeny = d3;

                string[] nesk = st[2].Split(' ');

                nemzet = nesk.First();
                kod = nesk.Last().Substring(1, nesk.Last().Length - 2);

            }


        }

        
    }
}
