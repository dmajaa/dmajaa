﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Pars2012
{
    class Program
    {
        static List<Versenyző> selejtezes = new List<Versenyző>();


        static void Main(string[] args)
        {
            Fajlbeolvasas();

            //5.feladat
            Console.WriteLine("5.feladat:");
            Console.WriteLine("Versenyzők száma a selejtezőben: " + selejtezes.Count + " fő" );

            //6.feladat
            int tovabbjutottakSzama = Tovabbjutottak();
            Console.WriteLine("6.feladat:");
            Console.WriteLine("78,00 m feletti eredménnyel továbbjutott: " + tovabbjutottakSzama + " fő");

            //9.feladat
            Console.WriteLine("9.feladat:");
            Versenyző legjobbEredmeny = LegjobbEredmeny();
            Console.WriteLine("A selejtező nyertese:");
            Console.WriteLine("Név: " + legjobbEredmeny.nev);
            Console.WriteLine("Csoport: " + legjobbEredmeny.csoport);
            Console.WriteLine("Nemzet: " + legjobbEredmeny.nemzet);
            Console.WriteLine("Nemzet kód: " + legjobbEredmeny.kod);
            Console.WriteLine("Sorozat: " + legjobbEredmeny.d1 + ";" + legjobbEredmeny.d2 + ";" + legjobbEredmeny.d3);
            Console.WriteLine("Eredmény: " + legjobbEredmeny.Eredmeny());



            Console.ReadLine();


        }

        static void Fajlbeolvasas()
        {
            try
            {

                using (StreamReader f = new StreamReader("Selejtezo2012.txt"))
                {
                    f.ReadLine(); 
                    while (!f.EndOfStream)
                    {
                        Versenyző versenyzo = new Versenyző(f.ReadLine());
                        selejtezes.Add(versenyzo);
                    }

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Hiba történt az állomány olvasása közben: " + ex.Message);
            }
        }

        static int Tovabbjutottak()
        {
            int tovabbjutottak = 0;
            foreach (Versenyző versenyzo in selejtezes)
            {
                if ((versenyzo.d2 == -2.0 || versenyzo.d3 == -2.0) ||
                    (versenyzo.d2 == -2.0 && versenyzo.d3 == -2.0))
                {
                    tovabbjutottak++;
                }
            }
            return tovabbjutottak;
        }

        static Versenyző LegjobbEredmeny()
        {
            Versenyző legjobbEredmeny = selejtezes[0]; 
            foreach (Versenyző versenyzo in selejtezes)
            {
                if (versenyzo.Eredmeny() > legjobbEredmeny.Eredmeny())
                {
                    legjobbEredmeny = versenyzo;
                }
            }
            return legjobbEredmeny;
        }

        public class Versenyző
        {
            public string nev, csoport, nemzeteskod, nemzet, kod;
            public double d1, d2, d3;

            public Versenyző(string sor)
            {
                string[] st = sor.Split(';');
                nev = st[0];
                csoport = st[1];
                nemzeteskod = st[2];
                d1 = dobasParse(st[3]);
                d2 = dobasParse(st[4]);
                d3 = dobasParse(st[5]);

                string[] nesk = st[2].Split(' ');

                nemzet = nesk.First();
                kod = nesk.Last().Substring(1, nesk.Last().Length - 2);


            }

            private double dobasParse(string dobas)
            {
                if (dobas == "X")
                {
                    return -1.0;
                }
                else if (dobas == "-")
                {
                    return -2.0;
                }
                else
                {
                    return double.Parse(dobas.Replace('.', ','));
                }
            }

            public double Eredmeny()
            {
                double maxDobas = Math.Max(d1, Math.Max(d2, d3));
                return (maxDobas);
            }

           

        }
    }

}
