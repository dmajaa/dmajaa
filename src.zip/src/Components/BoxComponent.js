const BoxComponent=(props)=>{
    const hatterBeallitas={
        backgroundColor: props.szin
    }
    return(
        <div className = "boxcomponent" style = {hatterBeallitas}>
            {props.szin}
        </div>
    );
}
export default BoxComponent;