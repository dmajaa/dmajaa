
import './App.css';

import BoxComponent from './Components/BoxComponent';
const App =()=> {
  return(
      <div classname= "App">
        App
        <BoxComponent szin = "red"/>
        <BoxComponent szin = "green"/>
        <BoxComponent szin = "blue"/>
      </div>
  );
}

export default App;
