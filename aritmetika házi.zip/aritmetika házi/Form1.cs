﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace aritmatika_házi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        List<string> szamok = new List<string>();
        private string szam1, szam2;
        private Aritmetika a;


        
        private void Beolvasas()
        {
            if(openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                StreamReader f = new StreamReader(openFileDialog1.FileName);
                int i = 0;
                while(!f.EndOfStream)
                {
                    szamok.Add(f.ReadLine());
                    string szam = "";
                    szam += szamok[i].Substring(0,5);
                    szam += "..........";
                    szam += szamok[i].Substring(szamok[i].Length-6, 5);
                    comboBox1.Items.Add(szam);
                    comboBox2.Items.Add(szam);
                    i++;
                }
                f.Close();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Visible = false;
            comboBox2.Visible = false;
            Beolvasas();

           /* string szam1 = "12345";
            string szam2 = "123456789";
            Aritmetika a = new Aritmetika(szam1, szam2);
            MessageBox.Show(a.Osszeadas()); */
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            comboBox1.Visible = true;
            comboBox2.Visible = true;
            textBox1.Visible = false;
            textBox2.Visible = false;

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            comboBox1.Visible = false;
            comboBox2.Visible = false;
            textBox1.Visible = true;
            textBox2.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            a = new Aritmetika(szam1, szam2);
            if (radioButton1.Checked)
            {
                label4.Text = "Eredmény: " + a.Osszeadas();
            }
            
            if(radioButton2.Checked)
            {
                //Kivonás
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            int n = textBox1.Text.Length;
            string sz = textBox1.Text;
            if (sz[n - 1] < 48 || sz[n - 1] > 57)
            {
                MessageBox.Show("Nem számot adtál meg, hanem valamilyen más karaktert!");
                textBox1.Text = sz.Substring(0, n - 1);

            }
            szam1 = textBox1.Text;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            int n = textBox2.Text.Length;
            string sz = textBox2.Text;
            if (sz[n - 1] < 48 || sz[n - 1] > 57)
            {
                MessageBox.Show("Nem számot adtál meg, hanem valamilyen más karaktert!");
                textBox2.Text = sz.Substring(0, n - 1);

            }
            szam2 = textBox2.Text;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            szam1 = comboBox1.Text;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            szam2 = comboBox2.Text;
        }

    }

    class Aritmetika
    {
        private string szam1, szam2;
        private string rovidsz, hosszusz;
        public Aritmetika(string sz1, string sz2) { 
            szam1 = sz1;
            szam2 = sz2;
            Kiegeszit();
        }

        private void Kiegeszit()
        {
            rovidsz = szam1.Length <= szam2.Length ? szam1 : szam2;
            hosszusz = szam1.Length > szam2.Length ? szam1 : szam2;
            int kul = hosszusz.Length - rovidsz.Length;
            for( int i = 0; i < kul; i++ )
            {
                rovidsz = "0" + rovidsz;
            }

        }

        public string Osszeadas()
        {
            string er = "";
            int m = 0;
            for (int i = hosszusz.Length-1; i >= 0; i--)
            {
                int a = (int)rovidsz[i]-48;
                int b = (int)hosszusz[i]-48;
                int c = (a + b + m) % 10;
                m = (a + b + c) / 10;
                er = c + er;

            }
            if (m > 0) er = 1 + er;

            return er;

        }
    }
}
